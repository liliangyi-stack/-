App({
  onLaunch() {
    console.log("小程序启动")
  }
})
