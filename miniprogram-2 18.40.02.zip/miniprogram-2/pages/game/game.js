Page({
    data: {
      questions: [
        {
          question: "“搞归一了” 在四川方言中是什么意思？",
          options: ["搞完了", "搞砸了"],
          correct: 0
        },
        {
          question: "“摆龙门阵” 在四川方言中的意思是？",
          options: ["打架", "聊天"],
          correct: 1
        },
        {
          question: "“巴适” 在四川方言中形容什么？",
          options: ["不舒服", "很舒服、很好"],
          correct: 1
        },
        {
          question: "“瓜娃子” 在四川方言中是什么意思？",
          options: ["聪明人", "傻子"],
          correct: 1
        },
        {
          question: "“晓得” 在四川方言中是什么意思？",
          options: ["不知道", "知道"],
          correct: 1
        },
        {
          question: "“莫得” 在四川方言中是什么意思？",
          options: ["没有", "很多"],
          correct: 0
        },
        {
          question: "“安逸” 在四川方言中形容什么？",
          options: ["危险", "舒服、满意"],
          correct: 1
        },
        {
          question: "“要得” 在四川方言中是什么意思？",
          options: ["拒绝", "同意、可以"],
          correct: 1
        },
        {
          question: "“撇脱” 在四川方言中是什么意思？",
          options: ["麻烦", "简单、方便"],
          correct: 1
        },
        {
          question: "“扯拐” 在四川方言中是什么意思？",
          options: ["正常", "出问题、出故障"],
          correct: 1
        }
      ],
      currentIndex: 0,
      result: "",
      showNextButton: false,
      gameCompleted: false,
      answered: false
    },
  
    // 回答选项
    answerQuestion(e) {
      if (this.data.gameCompleted || this.data.answered) return;
      
      const selected = parseInt(e.currentTarget.dataset.index);
      const correct = this.data.questions[this.data.currentIndex].correct;
      const isCorrect = selected === correct;
      
      // 设置已回答状态
      this.setData({
        answered: true
      });
      
      if (isCorrect) {
        this.setData({
          result: "✅ 正确！",
          showNextButton: true
        });
      } else {
        this.setData({
          result: "❌ 不对哦，再试试！"
        });
        
        // 2秒后重置回答状态（允许重新选择）
        setTimeout(() => {
          this.setData({
            answered: false,
            result: ""
          });
        }, 1000);
      }
    },
  
    // 下一题
    nextQuestion() {
      if (this.data.currentIndex < this.data.questions.length - 1) {
        this.setData({
          currentIndex: this.data.currentIndex + 1,
          result: "",
          showNextButton: false,
          answered: false
        });
      } else {
        this.setData({
          gameCompleted: true,
          result: "🎉 恭喜你完成所有题目！"
        });
      }
    },
  
    // 重新开始游戏
    restartGame() {
      this.setData({
        currentIndex: 0,
        result: "",
        showNextButton: false,
        gameCompleted: false,
        answered: false
      });
    }
  });