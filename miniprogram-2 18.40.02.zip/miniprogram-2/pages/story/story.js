Page({
    data: {
      stories: [
        {
          id: 1,
          title: "成都茶馆故事",
          audio: "/assets/audio/story1.mp3",
          image: "/assets/images/p1.jpg",
          playing: false,
          progress: 0
        },
        {
          id: 2,
          title: "重庆山城棒棒",
          audio: "/assets/audio/story2.mp3",
          image: "/assets/images/p2.jpg",
          playing: false,
          progress: 0
        },
        {
          id: 3,
          title: "游戏中的方言",
          audio: "/assets/audio/story3.mp3",
          image: "/assets/images/p3.jpg",
          playing: false,
          progress: 0
        },
        {
          id: 4,
          title: "川菜的历史",
          audio: "/assets/audio/story4.mp3",
          image: "/assets/images/p4.png",
          playing: false,
          progress: 0
        }
      ],
      audioContexts: {}
    },
    
    onLoad() {
      this.initAudioContexts();
    },
    
    // 初始化音频上下文
    initAudioContexts() {
      const contexts = {};
      this.data.stories.forEach(story => {
        const ctx = wx.createInnerAudioContext();
        ctx.src = story.audio;
        
        // 监听进度更新
        ctx.onTimeUpdate(() => {
          if (ctx.duration > 0) {
            const progress = (ctx.currentTime / ctx.duration) * 100;
            this.updateProgress(story.id, progress);
          }
        });
        
        // 监听音频结束
        ctx.onEnded(() => {
          this.stopAudio(story.id);
        });
        
        contexts[story.id] = ctx;
      });
      
      this.setData({ audioContexts: contexts });
    },
    
    // 播放/暂停音频
    toggleAudio(e) {
      const id = e.currentTarget.dataset.id;
      const story = this.data.stories.find(s => s.id === id);
      
      if (!story) return;
      
      // 停止其他音频
      this.stopAllAudio(id);
      
      // 切换当前音频状态
      const newStories = this.data.stories.map(s => {
        if (s.id === id) {
          if (s.playing) {
            this.data.audioContexts[id].pause();
            return { ...s, playing: false };
          } else {
            this.data.audioContexts[id].play();
            return { ...s, playing: true };
          }
        }
        return s;
      });
      
      this.setData({ stories: newStories });
    },
    
    // 更新进度
    updateProgress(id, progress) {
      this.setData({
        stories: this.data.stories.map(story => {
          if (story.id === id) {
            return { ...story, progress: progress };
          }
          return story;
        })
      });
    },
    
    // 停止特定音频
    stopAudio(id) {
      this.setData({
        stories: this.data.stories.map(story => {
          if (story.id === id) {
            this.data.audioContexts[id].pause();
            this.data.audioContexts[id].seek(0);
            return { ...story, playing: false, progress: 0 };
          }
          return story;
        })
      });
    },
    
    // 停止所有音频（除了当前操作的）
    stopAllAudio(currentId) {
      this.setData({
        stories: this.data.stories.map(story => {
          if (story.id !== currentId && story.playing) {
            this.data.audioContexts[story.id].pause();
            return { ...story, playing: false, progress: 0 };
          }
          return story;
        })
      });
    },
    
    onUnload() {
      // 页面卸载时销毁所有音频上下文
      Object.values(this.data.audioContexts).forEach(ctx => {
        ctx.destroy();
      });
    }
  });